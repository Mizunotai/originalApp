//
//  PlayGameViewController.m
//  Marbletime
//
//  Created by 大氣 on 2014/10/07.
//  Copyright (c) 2014年 大氣. All rights reserved.
//

#import "PlayGameViewController.h"
#import "ViewController.h"
@interface PlayGameViewController ()

@end

@implementation PlayGameViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UIImage *image1 =[UIImage imageNamed:@"desk.jpg"];
    [desk setImage:image1];
    //Play用のタイマー
    count[0]=0;
    count[1]=0;
    count[2]=0;
    count[3]=0;
    count[4]=0;
    count[5]=0;
    count[6]=0;
    count[7]=0;
    count[8]=0;
    count[9]=0;
    
    Playtime = 30;
    PlayTimers = [NSTimer scheduledTimerWithTimeInterval:1
                                                  target:self
                                                selector:@selector(playtime:)
                                                userInfo:nil
                                                 repeats:YES];
    TimeLabel.text = [NSString stringWithFormat:@"%d",Playtime];
    
    // メインのビー玉を追加
    UIImage *MainBidamaimg = [UIImage imageNamed:@"main_bidama.png"];
    mainBidama = [[UIImageView alloc] initWithImage:MainBidamaimg];
    mainBidama.frame = [[UIScreen mainScreen]  bounds];
    CGRect rect= CGRectMake(self.view.frame.size.width/2 - 15,self.view.frame.size.height-100, 40,  40);
    mainBidama.frame = rect;
    [self.view addSubview:mainBidama];
    
    /*固定ボールの追加*/
    //1
    UIImage *ballimg1 = [UIImage imageNamed:@"ball.png"];
    ball[0]= [[UIImageView alloc] initWithImage:ballimg1];
    ball[0].frame = [[UIScreen mainScreen]  bounds];
    CGRect rect1= CGRectMake(400,400, 35,  35);
    ball[0].frame = rect1;
    
    //2
    UIImage *ballimg2 = [UIImage imageNamed:@"ball.png"];
    ball[1]= [[UIImageView alloc] initWithImage:ballimg2];
    ball[1].frame = [[UIScreen mainScreen]  bounds];
    CGRect rect2= CGRectMake(400,400, 35,  35);
    ball[1].frame = rect2;
    
    //3
    UIImage *balling3 =[UIImage imageNamed:@"ball.png"];
    ball[2]=[[UIImageView alloc] initWithImage:balling3];
    ball[2].frame = [[UIScreen mainScreen] bounds];
    CGRect rect3 = CGRectMake(400,400, 35, 35);
    ball[2].frame =rect3;
    
    //4
    UIImage *balling4 =[UIImage imageNamed:@"ball.png"];
    ball[3]=[[UIImageView alloc] initWithImage:balling4];
    ball[3].frame = [[UIScreen mainScreen] bounds];
    CGRect rect4 = CGRectMake(400, 400, 35, 35);
    ball[3].frame =rect4;
    
    //5
    UIImage *balling5 =[UIImage imageNamed:@"ball.png"];
    ball[4]=[[UIImageView alloc] initWithImage:balling5];
    ball[4].frame = [[UIScreen mainScreen] bounds];
    CGRect rect5= CGRectMake(400,400, 35, 35);
    ball[4].frame =rect5;
    
    //6
    UIImage *balling6 =[UIImage imageNamed:@"ball.png"];
    ball[5]=[[UIImageView alloc] initWithImage:balling6];
    ball[5].frame = [[UIScreen mainScreen] bounds];
    CGRect rect6= CGRectMake(400,400, 35, 35);
    ball[5].frame =rect6;
    
    //7
    UIImage *balling7 =[UIImage imageNamed:@"ball.png"];
    ball[6]=[[UIImageView alloc] initWithImage:balling7];
    ball[6].frame = [[UIScreen mainScreen] bounds];
    CGRect rect7= CGRectMake(400,400, 35, 35);
    ball[6].frame =rect7;
    
    //8
    UIImage *balling8 =[UIImage imageNamed:@"ball.png"];
    ball[7]=[[UIImageView alloc] initWithImage:balling8];
    ball[7].frame = [[UIScreen mainScreen] bounds];
    CGRect rect8= CGRectMake(400,400, 35, 35);
    ball[7].frame =rect8;
    
    //9
    UIImage *balling9 =[UIImage imageNamed:@"ball.png"];
    ball[8]=[[UIImageView alloc] initWithImage:balling9];
    ball[8].frame = [[UIScreen mainScreen] bounds];
    CGRect rect9= CGRectMake(400,400, 35, 35);
    ball[8].frame =rect9;
    
    //10
    UIImage *balling10 =[UIImage imageNamed:@"ball.png"];
    ball[9]=[[UIImageView alloc] initWithImage:balling10];
    ball[9].frame = [[UIScreen mainScreen] bounds];
    CGRect rect10= CGRectMake(400,400, 35, 35);
    ball[9].frame =rect10;
    
    
    
    
    
    
    if (number == 1) {
        
        //1個目の座標
        ball[0].center = CGPointMake(50, 40);
        [self.view addSubview:ball[0]];
        
        //2個目の座標
        ball[1].center = CGPointMake(299, 47);
        [self.view addSubview:ball[1]];
        
        //3個目の座標
        ball[2].center = CGPointMake(300, 300);
        [self.view addSubview:ball[2]];
        
    }
    
    if(number ==2) {
        
        //1個目の座標
        ball[0].center = CGPointMake(165, 88);
        [self.view addSubview:ball[0]];
        //２個目の座票
        ball[1].center = CGPointMake(300, 333);
        [self.view addSubview:ball[1]];
        //3個目の座標
        ball[2].center = CGPointMake(19, 222);
        [self.view addSubview:ball[2]];
        //4個目の座標
        ball[3].center = CGPointMake(45, 14);
        [self.view addSubview:ball[3]];
        
    }else if (number == 3){
        
        //1個目の座表
        ball[0].center = CGPointMake(33, 188);
        [self.view addSubview:ball[0]];
        //２個目の座票
        ball[1].center = CGPointMake(156, 150);
        [self.view addSubview:ball[1]];
        //3個目の座標
        ball[2].center = CGPointMake(99, 278);
        [self.view addSubview:ball[2]];
        //4個目の座標
        ball[3].center = CGPointMake(204, 33);
        [self.view addSubview:ball[3]];
        //５個目の座標
        ball[4].center = CGPointMake(243,333);
        [self.view addSubview:ball[4]];
        
    }else if (number == 4){
        //1個目の座表
        ball[0].center = CGPointMake(34, 188);
        [self.view addSubview:ball[0]];
        //２個目の座票
        ball[1].center = CGPointMake(156, 57);
        [self.view addSubview:ball[1]];
        //3個目の座標
        ball[2].center = CGPointMake(278, 278);
        [self.view addSubview:ball[2]];
        //4個目の座標
        ball[3].center = CGPointMake(204, 300);
        [self.view addSubview:ball[3]];
        //５個目の座標
        ball[4].center = CGPointMake(39,39);
        [self.view addSubview:ball[4]];
        //６個目の座標
        ball[5].center=CGPointMake(100,100);
        [self.view addSubview:ball[5]];
        
    }else if (number == 5){
        //1個目の座表
        ball[0].center = CGPointMake(17,17);
        [self.view addSubview:ball[0]];
        //２個目の座票
        ball[1].center = CGPointMake(300, 400);
        [self.view addSubview:ball[1]];
        //        //3個目の座標
        ball[2].center = CGPointMake(100, 278);
        [self.view addSubview:ball[2]];
        //        //4個目の座標
        ball[3].center = CGPointMake(300,17);
        [self.view addSubview:ball[3]];
        //        //５個目の座標
        ball[4].center = CGPointMake(200,100);
        [self.view addSubview:ball[4]];
        //        //６個目の座標
        ball[5].center=CGPointMake(50,200);
        [self.view addSubview:ball[5]];
        
        //7個目の座標
        ball[6].center = CGPointMake(250, 250);
        [self.view addSubview:ball[6]];
        
    }else if (number == 6){
        //1個目の座表
        ball[0].center = CGPointMake(17,240);
        [self.view addSubview:ball[0]];
        //        //２個目の座票
        ball[1].center = CGPointMake(120, 240);
        [self.view addSubview:ball[1]];
        //        //        //3個目の座標
        ball[2].center = CGPointMake(220, 240);
        [self.view addSubview:ball[2]];
        //        //        //4個目の座標
        ball[3].center = CGPointMake(310,240);
        [self.view addSubview:ball[3]];
        //        //        //５個目の座標
        ball[4].center = CGPointMake(200,100);
        [self.view addSubview:ball[4]];
        //        //        //６個目の座標
        ball[5].center=CGPointMake(50,350);
        [self.view addSubview:ball[5]];
        //
        //7個目の座標
        ball[6].center = CGPointMake(250, 350);
        [self.view addSubview:ball[6]];
        
        //８個目の座標
        ball[7].center = CGPointMake(60, 100);
        [self.view addSubview:ball[7]];
        
    }else if (number == 7){
        //1個目の座表
        ball[0].center = CGPointMake(17,200);
        [self.view addSubview:ball[0]];
        //        //        //２個目の座票
        ball[1].center = CGPointMake(17, 100);
        [self.view addSubview:ball[1]];
        //        //        //        //3個目の座標
        ball[2].center = CGPointMake(100, 100);
        [self.view addSubview:ball[2]];
        //        //        //        //4個目の座標
        ball[3].center = CGPointMake(183,100);
        [self.view addSubview:ball[3]];
        //        //        //        //５個目の座標
        ball[4].center = CGPointMake(266,100);
        [self.view addSubview:ball[4]];
        //        //        //        //６個目の座標
        ball[5].center=CGPointMake(266,200);
        [self.view addSubview:ball[5]];
        //        //
        //        //7個目の座標
        ball[6].center = CGPointMake(266, 300);
        [self.view addSubview:ball[6]];
        //
        //        //８個目の座標
        ball[7].center = CGPointMake(266, 400);
        [self.view addSubview:ball[7]];
        
        //9個目の座標
        ball[8].center = CGPointMake(17, 150);
        [self.view addSubview:ball[8]];
        
    }else if (number == 8){
        //1個目の座表
        ball[0].center = CGPointMake(17,200);
        [self.view addSubview:ball[0]];
        //２個目の座票
        ball[1].center = CGPointMake(17, 100);
        [self.view addSubview:ball[1]];
        //3個目の座標
        ball[2].center = CGPointMake(17, 300);
        [self.view addSubview:ball[2]];
        //4個目の座標
        ball[3].center = CGPointMake(17,400);
        [self.view addSubview:ball[3]];
        //５個目の座標
        ball[4].center = CGPointMake(117,100);
        [self.view addSubview:ball[4]];
        //６個目の座標
        ball[5].center=CGPointMake(217,100);
        [self.view addSubview:ball[5]];
        //7個目の座標
        ball[6].center = CGPointMake(300, 100);
        [self.view addSubview:ball[6]];
        //８個目の座標
        ball[7].center = CGPointMake(300,200);
        [self.view addSubview:ball[7]];
        
        //9個目の座標
        ball[8].center = CGPointMake(300, 300);
        [self.view addSubview:ball[8]];
        
        //10個目の座標
        ball[9].center = CGPointMake(300, 400);
        [self.view addSubview:ball[9]];
        
    }else if (number == 9){
        //1個目の座表
        ball[0].center = CGPointMake(17,70);
        [self.view addSubview:ball[0]];
        //２個目の座票
        ball[1].center = CGPointMake(300, 70);
        [self.view addSubview:ball[1]];
        //3個目の座標
        ball[2].center = CGPointMake(161, 70);
        [self.view addSubview:ball[2]];
        //4個目の座標
        ball[3].center = CGPointMake(17,300);
        [self.view addSubview:ball[3]];
        //５個目の座標
        ball[4].center = CGPointMake(161,300);
        [self.view addSubview:ball[4]];
        //６個目の座標
        ball[5].center=CGPointMake(300,300);
        [self.view addSubview:ball[5]];
        //7個目の座標
        ball[6].center = CGPointMake(17, 200);
        [self.view addSubview:ball[6]];
        //８個目の座標
        ball[7].center = CGPointMake(17,400);
        [self.view addSubview:ball[7]];
        
        //9個目の座標
        ball[8].center = CGPointMake(300, 200);
        [self.view addSubview:ball[8]];
        
        //10個目の座標
        ball[9].center = CGPointMake(300, 400);
        [self.view addSubview:ball[9]];
        
    }
    
    
    
    
    
    
    
    
    
    //PanGestureの導入
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc]
                                          initWithTarget:self action:@selector(panAction:)];
    panGesture.maximumNumberOfTouches = 5;  //指は最大1本まで反応
    [mainBidama addGestureRecognizer:panGesture];   //ビー玉にPanGesture追加
    
    
    //ビー玉を触れるように
    mainBidama.userInteractionEnabled = YES;
    
    //効果音の設定
    NSString *soundFilePath =
    [[NSBundle mainBundle] pathForResource: @"audio"
                                    ofType: @"mp3"];
    NSURL *fileURL =
    [[NSURL alloc] initFileURLWithPath: soundFilePath];
    
    audio =
    [[AVAudioPlayer alloc] initWithContentsOfURL: fileURL
                                           error: nil];
    [audio prepareToPlay];
    [audio play];
    
    NSString *sound =
    [[NSBundle mainBundle] pathForResource:@"かっち"
                                    ofType:@"mp3"];
    NSURL *soundURL =
    [[NSURL alloc]initFileURLWithPath:sound ];
    audio2 =
    [[AVAudioPlayer alloc] initWithContentsOfURL:soundURL error:nil];
    [audio2 prepareToPlay];
    
    
    home =[[UIButton alloc]initWithFrame:CGRectMake(86, 268,159, 30)];
    
    mouitido =[[UIButton alloc]initWithFrame:CGRectMake(89, 186, 50, 50)];
    
    saikai =[[UIButton alloc]initWithFrame:CGRectMake(196, 186, 44,44)];
    
    }
//ビー玉動かす用のTimerメソッド

- (void)ballMove:(NSTimer *)_timer {
    
    
    
    
    CGRect main = [[UIScreen mainScreen] applicationFrame];
    
    mainBidama.center = CGPointMake(mainBidama.center.x + ballMoveX/speed, mainBidama.center.y + ballMoveY/speed);
    
    
    //ビー玉と横壁の当たり判定
    if(mainBidama.center.x - mainBidama.bounds.size.width / 2 < 0){
        ballMoveX = - ballMoveX;
        //    speed += 0.01;
    }
    if(mainBidama.center.x +mainBidama.bounds.size.width / 2 > main.size.width){
        ballMoveX = - ballMoveX;
        //    speed += 0.01;
    }
    // ビー玉と縦壁の当たり判定
    if(mainBidama.center.y - mainBidama.bounds.size.height / 2 < 0){
        ballMoveY = - ballMoveY;
        //    speed += 0.01;
    }
    if(mainBidama.center.y +mainBidama.bounds.size.height / 2 > main.size.height){
        ballMoveY = - ballMoveY;
        //    speed += 0.01;
    }
    
    
    //    ビー玉と止まってるボールのあたり判定
    float distance = (mainBidama.center.x - ball[0].center.x)*(mainBidama.center.x - ball[0].center.x)
    +(mainBidama.center.y - ball[0].center.y)*(mainBidama.center.y- ball[0].center.y);
    
    float distance2 = (mainBidama.center.x - ball[1].center.x)*(mainBidama.center.x - ball[1].center.x)
    +(mainBidama.center.y - ball[1].center.y)*(mainBidama.center.y- ball[1].center.y);
    
    float distance3 = (mainBidama.center.x - ball[2].center.x)*(mainBidama.center.x - ball[2].center.x)
    +(mainBidama.center.y - ball[2].center.y)*(mainBidama.center.y- ball[2].center.y);
    
    float distance4 = (mainBidama.center.x - ball[3].center.x)*(mainBidama.center.x - ball[3].center.x)
    +(mainBidama.center.y - ball[3].center.y)*(mainBidama.center.y- ball[3].center.y);
    
    float distance5 = (mainBidama.center.x - ball[4].center.x)*(mainBidama.center.x - ball[4].center.x)
    +(mainBidama.center.y - ball[4].center.y)*(mainBidama.center.y- ball[4].center.y);
    
    float distance6 = (mainBidama.center.x - ball[5].center.x)*(mainBidama.center.x - ball[5].center.x)
    +(mainBidama.center.y - ball[5].center.y)*(mainBidama.center.y- ball[5].center.y);
    
    float distance7 = (mainBidama.center.x - ball[6].center.x)*(mainBidama.center.x - ball[6].center.x)
    +(mainBidama.center.y - ball[6].center.y)*(mainBidama.center.y- ball[6].center.y);
    
    float distance8 = (mainBidama.center.x - ball[7].center.x)*(mainBidama.center.x - ball[7].center.x)
    +(mainBidama.center.y - ball[7].center.y)*(mainBidama.center.y- ball[7].center.y);
    
    float distance9 = (mainBidama.center.x - ball[8].center.x)*(mainBidama.center.x - ball[8].center.x)
    +(mainBidama.center.y - ball[8].center.y)*(mainBidama.center.y- ball[8].center.y);
    
    float distance10 = (mainBidama.center.x - ball[9].center.x)*(mainBidama.center.x - ball[9].center.x)
    +(mainBidama.center.y - ball[9].center.y)*(mainBidama.center.y- ball[9].center.y);
    
    
    
    if (distance<40*40) {
        //1個目のボールとの当たり判定
        ballMoveX=-ballMoveX;
        ballMoveY=-ballMoveY;
        NSLog(@"ATARI:%.1f", distance);
        //ビー玉とボールが当たったあとにかわる画像
        UIImage *ballimag =[UIImage imageNamed:@"green_ball.png"];
        CGPoint point = ball[0].center;
        ball[0]=[[UIImageView alloc] initWithImage:ballimag];
        ball[0].center = point;
        [self.view addSubview:ball[0]];
        [audio2 play];
        if (number ==1 ){
            count[0]=1;
                    }
        if (number == 2){
            count[0] =2;
        }
        if (number ==3) {
            count[0] =3;
        }
        if (number == 4) {
            count[0]= 4;
        }
        if (number == 5) {
            count[0]=5;
        }
        if (number == 6) {
            count[0]=6;
        }
        if (number== 7) {
            count[0] = 7;
        }
        if (number == 8) {
            count[0]=8;
        }
        if (number == 9) {
            count[0]= 9;
        }
    }else {
        ballMoveX=+ballMoveX;
        ballMoveY=+ballMoveY;
        NSLog(@"HAZURE:%.1f", distance);
        
    }
    
    
    if (distance2<40*40) {
        //2個目のボールとの当たり判定
        ballMoveX=-ballMoveX;
        ballMoveY=-ballMoveY;
        NSLog(@"ATARI:%.1f", distance2);
        //ビー玉とボールが当たったあとにかわる画像
        UIImage *ballimag =[UIImage imageNamed:@"green_ball.png"];
        CGPoint point = ball[1].center;
        ball[1]=[[UIImageView alloc] initWithImage:ballimag];
        ball[1].center = point;
        [self.view addSubview:ball[1]];
        [audio2 play];
        if (number ==1){
            count[1]=1;
         
        }
        if (number ==2) {
            count[1] =2;
        }
        if (number ==3) {
            count[1] =3;
        }
        if (number ==4) {
            count[1] =4;
        }
        if (number ==5) {
            count[1] =5;
        }
        if (number ==6) {
            count[1] =6;
        }
        if (number ==7) {
            count[1] =7;
        }
        if (number ==8) {
            count[1] =8;
        }
        if (number ==9) {
            count[1] =9;
        }
        
    }else {
        ballMoveX=+ballMoveX;
        ballMoveY=+ballMoveY;
        NSLog(@"HAZURE:%.1f", distance2);
        
    }
    
    if (distance3<40*40) {
        //３個目のボールとの当たり判定
        ballMoveX=-ballMoveX;
        ballMoveY=-ballMoveY;
        NSLog(@"ATARI:%.1f", distance3);
        //ビー玉とボールが当たったあとにかわる画像
        UIImage *ballimag =[UIImage imageNamed:@"green_ball.png"];
        CGPoint point = ball[2].center;
        ball[2]=[[UIImageView alloc] initWithImage:ballimag];
        ball[2].center = point;
        [self.view addSubview:ball[2]];
        [audio2 play];
        if (number ==1){
            count[2]= 1;
                    }
        if (number ==2) {
            count[2]=2;
        }
        if (number ==3){
            count[2]=3;
        }
        if (number ==4){
            count[2]=4;
        }
        if (number ==5){
            count[2]=5;
        }
        if (number ==6){
            count[2]=6;
        }
        if (number ==7){
            count[2]=7;
        }
        if (number ==8){
            count[2]=8;
        }
        if (number ==9){
            count[2]=9;
        }
    }else {
        ballMoveX=+ballMoveX;
        ballMoveY=+ballMoveY;
        NSLog(@"HAZURE:%.1f", distance3);
    }
    
    if (distance4<40*40) {
        //4個目のボールとの当たり判定
        ballMoveX=-ballMoveX;
        ballMoveY=-ballMoveY;
        NSLog(@"ATARI:%.1f", distance4);
        //ビー玉とボールが当たったあとにかわる画像
        UIImage *ballimag =[UIImage imageNamed:@"green_ball.png"];
        CGPoint point = ball[3].center;
        ball[3]=[[UIImageView alloc] initWithImage:ballimag];
        ball[3].center = point;
        [self.view addSubview:ball[3]];
        [audio2 play];
        
        if (number ==2) {
            count[3] =2;
        }
        if (number ==3) {
            count[3] =3;
        }
        if (number ==4) {
            count[3] =4;
        }
        if (number ==5) {
            count[3] =5;
        }
        if (number ==6) {
            count[3] =6;
        }
        if (number ==7) {
            count[3] =7;
        }
        if (number ==8) {
            count[3] =8;
        }
        if (number ==9) {
            count[3] =9;
        }
    }else {
        ballMoveX=+ballMoveX;
        ballMoveY=+ballMoveY;
        NSLog(@"HAZURE:%.1f", distance4);
    }
    
    if (distance5<40*40) {
        //５個目のボールとの当たり判定
        ballMoveX=-ballMoveX;
        ballMoveY=-ballMoveY;
        NSLog(@"ATARI:%.1f", distance5);
        //ビー玉とボールが当たったあとにかわる画像
        UIImage *ballimag =[UIImage imageNamed:@"green_ball.png"];
        CGPoint point = ball[4].center;
        ball[4]=[[UIImageView alloc] initWithImage:ballimag];
        ball[4].center = point;
        [self.view addSubview:ball[4]];
        [audio2 play];
        
        if (number== 3) {
            count[4] =3;
        }
        if (number== 4) {
            count[4] =4;
        }
        if (number== 5) {
            count[4] =5;
        }
        if (number== 6) {
            count[4] =6;
        }
        if (number== 7) {
            count[4] =7;
        }
        if (number== 8) {
            count[4] =8;
        }
        if (number== 9) {
            count[4] =9;
        }
    }else {
        ballMoveX=+ballMoveX;
        ballMoveY=+ballMoveY;
        NSLog(@"HAZURE:%.1f", distance5);
    }
    if (distance6 < 40*40) {
        //６個目のボールとの当たり判定
        ballMoveX=-ballMoveX;
        ballMoveY=-ballMoveY;
        //ビー玉とボールが当たったあとにかわる画像
        UIImage *ballimag = [UIImage imageNamed:@"green_ball.png"];
        CGPoint point = ball[5].center;
        ball[5]=[[UIImageView alloc] initWithImage:ballimag];
        ball[5].center =point;
        [self.view addSubview:ball[5]];
        [audio2 play];
        if (number == 4) {
            count[5]= 4;
        }
        if (number == 5) {
            count[5]= 5;
        }
        if (number == 6) {
            count[5]= 6;
        }
        if (number == 7) {
            count[5]= 7;
        }
        if (number == 8) {
            count[5]= 8;
        }
        if (number == 9) {
            count[5]= 9;
        }
    }else{
        ballMoveX=+ballMoveX;
        ballMoveY=+ballMoveY;
    }
    if (distance7 < 40*40) {
        //７個目のボールとの当たり判定
        ballMoveX=-ballMoveX;
        ballMoveY=-ballMoveY;
        //ビー玉とボールが当たったあとにかわる画像
        UIImage *ballimag = [UIImage imageNamed:@"green_ball.png"];
        CGPoint point = ball[6].center;
        ball[6]=[[UIImageView alloc] initWithImage:ballimag];
        ball[6].center = point;
        [self.view addSubview:ball[6]];
        [audio2 play];
        if (number == 5) {
            count[6]=5;
        }
        if (number == 6) {
            count[6]=6;
        }
        if (number == 7) {
            count[6]=7;
        }
        if (number == 8) {
            count[6]=8;
        }
        if (number ==9) {
            count[6]=9;
        }
    }else{
        ballMoveX=+ballMoveX;
        ballMoveY=+ballMoveY;
    }
    if (distance8 < 40*40) {
        //８個目のボールとの当たり判定
        ballMoveX=-ballMoveX;
        ballMoveY=-ballMoveY;
        //ビー玉とボールが当たったあとにかわる画像
        UIImage *ballimag = [UIImage imageNamed:@"green_ball.png"];
        CGPoint point = ball[7].center;
        ball[7]=[[UIImageView alloc] initWithImage:ballimag];
        ball[7].center = point;
        [self.view addSubview:ball[7]];
        [audio2 play];
        if (number == 6) {
            count[7]=6;
        }
        if (number == 7) {
            count[7]=7;
        }
        if (number == 8) {
            count[7]=8;
        }
        if (number == 9) {
            count[7]=9;
        }
    }else{
        ballMoveX=+ballMoveX;
        ballMoveY=+ballMoveY;
    }
    if (distance9 < 40*40) {
        //9個目のボールとの当たり判定
        ballMoveX=-ballMoveX;
        ballMoveY=-ballMoveY;
        //ビー玉とボールが当たったあとにかわる画像
        UIImage *ballimag = [UIImage imageNamed:@"green_ball.png"];
        CGPoint point = ball[8].center;
        ball[8]=[[UIImageView alloc] initWithImage:ballimag];
        ball[8].center = point;
        [self.view addSubview:ball[8]];
        [audio2 play];
        if (number == 7) {
            count[8]=7;
        }
        if (number == 8) {
            count[8]=8;
        }
        if (number == 9) {
            count[8]=9;
        }
        
    }else{
        ballMoveX=+ballMoveX;
        ballMoveY=+ballMoveY;
    }if (distance10 < 40*40) {
        //１０個目のボールと当たり判定
        ballMoveX=-ballMoveX;
        ballMoveY=-ballMoveY;
        //ビー玉とボールが当たったあとにかわる画像
        UIImage *ballimag = [UIImage imageNamed:@"green_ball.png"];
        CGPoint point = ball[9].center;
        ball[9]=[[UIImageView alloc] initWithImage:ballimag];
        ball[9].center = point;
        [self.view addSubview:ball[9]];
        [audio2 play];
        if (number==8) {
            count[9]=8;
        }
        if (number==9) {
            count[9]=9;
        }
        
    }else{
        ballMoveX=+ballMoveX;
        ballMoveY=+ballMoveY;
    }
    
    speed += 0.003;
    
    if(speed >= 0.7){
        
        [timer invalidate];
        moving = NO;
    }
}
- (void)speedCount:(NSTimer *)_timer {
    speed = speed += 0.01;
}
- (void)panAction:(UIPanGestureRecognizer *)sender {
    
    if(moving == NO){
        //座標習得
        CGPoint currentPoint = [sender translationInView:self.view];
        
        //ドラッグ始め
        if(sender.state == UIGestureRecognizerStateBegan){
            startPoint = currentPoint;
            //ドラッグ始めの座標を習得
            
            speed = 0.01;
            //ビー玉を動かすタイマー
        }
        
        
        //ドラッグ終わり
        if (sender.state == UIGestureRecognizerStateEnded){
            [speedTimer invalidate];
            
            endPoint = currentPoint;
            //ドラッグ終わりの座標を習得
            
            //始めと終わりの距離の差を習得
            moveX = endPoint.x - startPoint.x;
            moveY = endPoint.y - startPoint.y;
            
            //角度の設定
            degree = atan(moveY/moveX);
            //tan^-1で角度習得
            
            if(degree < 0){ //第一象限角度のみ習得
                //向きは動かす時に設定
                degree *= -1;
            }
            NSLog(@"%f",degree);
            
            
            if(moveX >= 0){
                ballMoveX = cos(degree) *0.3;
            }else{
                ballMoveX = -cos(degree) *0.3;
            }
            
            // y方向(縦)の向き
            if(moveY >= 0){
                ballMoveY = sin(degree) *0.3;
            }else{
                
                ballMoveY = -sin(degree) *0.3;
            }
            
            
            
            //ビー玉を動かすタイマー
            timer = [NSTimer scheduledTimerWithTimeInterval:0.01
                                                     target:self
                                                   selector:@selector(ballMove:)
                                                   userInfo:nil
                                                    repeats:YES];
            moving= YES;
        }
        
    }
    
}

-(void)playtime:(NSTimer *)time{
    Playtime -=1;
    
    if (Playtime ==0){
        
        UIButton *Endbtn = [[UIButton alloc]
                            initWithFrame:CGRectMake(71, 181, 178, 123)] ;  // ボタンのサイズを指定する
        
        UIImage *img = [UIImage imageNamed:@"GameOverBtn.png"];  // ボタンにする画像を生成する
        [Endbtn setBackgroundImage:img forState:UIControlStateNormal];  // 画像をセットする
        // ボタンが押された時にHomeメソッドを呼び出す
        [Endbtn addTarget:self
                   action:@selector(Home:) forControlEvents:UIControlEventTouchUpInside];
        
        //[desk insertSubview:btn atIndex:0];
        [self.view addSubview:Endbtn];
        [PlayTimers invalidate];
        mainBidama.userInteractionEnabled = NO;
        
    }
    
    /*レベル１*/
    if (count[0] && count[1] && count[2]  == 1){
        /*クリアした時にクリアボタンの表示*/
        UIButton *clearbtn = [[UIButton alloc]
                              initWithFrame:CGRectMake(71, 181, 178, 123)];
        UIImage *clearimg = [UIImage imageNamed:@"ClearBtn.png"];
        [clearbtn setBackgroundImage:clearimg forState:UIControlStateNormal];
        [clearbtn addTarget:self
                     action:@selector(Home:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:clearbtn];
        [PlayTimers invalidate];
        [audio stop];
        [audio2 stop];
        //ビー玉を触れなくする
        mainBidama.userInteractionEnabled = NO;
        
        countUD =[NSUserDefaults standardUserDefaults];//取得
        clearcount =3;//くりあ用の数
        
        [countUD setInteger:clearcount forKey:@"key"];//クリア用の数を保存
        
        
    }
    /*レベル２*/
    if (count[0] ==2 && count[1] ==2 && count[2] ==2 && count[3] ==2) {
        
        
        /*クリアした時にクリアボタンの表示*/
        UIButton *clearbtn = [[UIButton alloc]
                              initWithFrame:CGRectMake(71, 181, 178, 123)];
        UIImage *clearimg = [UIImage imageNamed:@"ClearBtn.png"];
        [clearbtn setBackgroundImage:clearimg forState:UIControlStateNormal];
        [clearbtn addTarget:self
                     action:@selector(Home:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:clearbtn];
        [PlayTimers invalidate];
        
        [audio2 stop];
        //ビー玉を触れなくする
        mainBidama.userInteractionEnabled = NO;
        countUD =[NSUserDefaults standardUserDefaults];//取得
        clearcount =5;
        [countUD setInteger:clearcount forKey:@"key"];//クリア用の数を保存
    }
    /*レベル３*/
    if (count[0] == 3 && count[1] == 3 && count[2] == 3 && count[3] == 3 && count[4] ==3) {
        //        clearCount =6 ;
        //       countUD =[NSUserDefaults standardUserDefaults];
        //        [countUD setInteger:clearCount forKey:@"key"];
        
        /*クリアした時にクリアボタンの表示*/
        UIButton *clearbtn = [[UIButton alloc]
                              initWithFrame:CGRectMake(71, 181, 178, 123)];
        UIImage *clearimg = [UIImage imageNamed:@"ClearBtn.png"];
        [clearbtn setBackgroundImage:clearimg forState:UIControlStateNormal];
        [clearbtn addTarget:self
                     action:@selector(Home:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:clearbtn];
        [PlayTimers invalidate];
        [audio2 stop];
        //ビー玉を触れなくする
        mainBidama.userInteractionEnabled = NO;
        clearcount =6;
        countUD =[NSUserDefaults standardUserDefaults];//クリア用の数を保存
        [countUD setInteger:clearcount forKey:@"key"];//クリア用の数を保存
    }
    /*レベル４*/
    if (count[0] == 4 && count[1] == 4 && count[2] == 4 && count[3] == 4 && count[4] == 4 && count[5] == 4 ){
        /*クリアした時にクリアボタンの表示*/
        UIButton *clearbtn = [[UIButton alloc]
                              initWithFrame:CGRectMake(71, 181, 178, 123)];
        UIImage *clearimg = [UIImage imageNamed:@"ClearBtn.png"];
        [clearbtn setBackgroundImage:clearimg forState:UIControlStateNormal];
        [clearbtn addTarget:self
                     action:@selector(Home:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:clearbtn];
        [PlayTimers invalidate];
        [audio2 stop];
        
        mainBidama.userInteractionEnabled = NO; //ビー玉を触れなくする
        clearcount = 8;
        countUD = [NSUserDefaults standardUserDefaults];
        [countUD setInteger:clearcount forKey:@"key"];
    }
    /*レベル５*/
    if (count[0] == 5 && count[1] == 5 && count[2] == 5 && count[3] == 5 && count[4] == 5 && count[5] == 5 && count[6]== 5) {
        /*クリアした時にクリアボタンの表示*/
        UIButton *clearbtn = [[UIButton alloc]
                              initWithFrame:CGRectMake(71, 181, 178, 123)];
        UIImage *clearimg = [UIImage imageNamed:@"ClearBtn.png"];
        [clearbtn setBackgroundImage:clearimg forState:UIControlStateNormal];
        [clearbtn addTarget:self
                     action:@selector(Home:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:clearbtn];
        [PlayTimers invalidate];
        [audio2 stop];
        //ビー玉を触れなくする
        mainBidama.userInteractionEnabled = NO;
        
        clearcount =10;
        countUD =[NSUserDefaults standardUserDefaults];
        [countUD setInteger:clearcount forKey:@"key"];
    }
    /*レベル６*/
    if (count[0] == 6 && count[1] == 6 && count[2] == 6 && count[3] == 6 && count[4] == 6 && count[5] == 6 && count[6]== 6 && count[7]== 6) {
        /*クリアした時にクリアボタンの表示*/
        UIButton *clearbtn = [[UIButton alloc]
                              initWithFrame:CGRectMake(71, 181, 178, 123)];
        UIImage *clearimg = [UIImage imageNamed:@"ClearBtn.png"];
        [clearbtn setBackgroundImage:clearimg forState:UIControlStateNormal];
        [clearbtn addTarget:self
                     action:@selector(Home:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:clearbtn];
        [PlayTimers invalidate];
        [audio2 stop];
        //ビー玉を触れなくする
        mainBidama.userInteractionEnabled = NO;
        
        clearcount =12;
        countUD =[NSUserDefaults standardUserDefaults];//クリア用の数を保存
        [countUD setInteger:clearcount forKey:@"key"];//クリア用の数を保存
        
    }
    /*レベル７*/
    if (count[0] == 7 && count[1] == 7 && count[2] == 7 && count[3] == 7 && count[4] == 7 && count[5] == 7 && count[6]== 7 && count[7]== 7 && count[8]== 7) {
        /*クリアした時にクリアボタンの表示*/
        UIButton *clearbtn = [[UIButton alloc]
                              initWithFrame:CGRectMake(71, 181, 178, 123)];
        UIImage *clearimg = [UIImage imageNamed:@"ClearBtn.png"];
        [clearbtn setBackgroundImage:clearimg forState:UIControlStateNormal];
        [clearbtn addTarget:self
                     action:@selector(Home:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:clearbtn];
        [PlayTimers invalidate];
        [audio2 stop];
        //ビー玉を触れなくする
        mainBidama.userInteractionEnabled = NO;
        clearcount =14;
        countUD =[NSUserDefaults standardUserDefaults];//クリア用の数を保存
        [countUD setInteger:clearcount forKey:@"key"];//クリア用の数を保存
        
    }
    /*レベル８*/
    if (count[0] == 8 && count[1] == 8 && count[2] == 8 && count[3] == 8 && count[4] == 8 && count[5] == 8 && count[6]== 8 && count[7]== 8 && count[8]== 8 && count[9]==8) {
        /*クリアした時にクリアボタンの表示*/
        UIButton *clearbtn = [[UIButton alloc]
                              initWithFrame:CGRectMake(71, 181, 178, 123)];
        UIImage *clearimg = [UIImage imageNamed:@"ClearBtn.png"];
        [clearbtn setBackgroundImage:clearimg forState:UIControlStateNormal];
        [clearbtn addTarget:self
                     action:@selector(Home:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:clearbtn];
        [PlayTimers invalidate];
        [audio2 stop];
        //ビー玉を触れなくする
        mainBidama.userInteractionEnabled = NO;
        clearcount =16;
        countUD =[NSUserDefaults standardUserDefaults];//クリア用の数を保存
        [countUD setInteger:clearcount forKey:@"key"];//クリア用の数を保存
    }
    /*レベル９*/
    if (count[0] == 9 && count[1] == 9 && count[2] == 9 && count[3] == 9 && count[4] == 9 && count[5] == 9 && count[6]== 9 && count[7]== 9 && count[8]== 9 && count[9]==9) {
        /*クリアした時にクリアボタンの表示*/
        UIButton *clearbtn = [[UIButton alloc]
                              initWithFrame:CGRectMake(71, 181, 178, 123)];
        UIImage *clearimg = [UIImage imageNamed:@"ClearBtn.png"];
        [clearbtn setBackgroundImage:clearimg forState:UIControlStateNormal];
        [clearbtn addTarget:self
                     action:@selector(Home:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:clearbtn];
        [PlayTimers invalidate];
        [audio2 stop];
        //ビー玉を触れなくする
        mainBidama.userInteractionEnabled = NO;
        
    }
    TimeLabel.text =[NSString stringWithFormat:@"%d",Playtime];
    
}
-(void)Home:(UIButton *)button {
    UIViewController *view = [self.storyboard instantiateViewControllerWithIdentifier:@"Home"];
    [self presentViewController: view animated:YES completion: nil];
    
}

-(IBAction)stop{
    [PlayTimers invalidate];
    
    mainBidama.userInteractionEnabled= NO;
    //スットプ時ホームボタンを表示する
    UIImage *homeimg =[UIImage imageNamed:@"ホームへ.png"];
    [home setBackgroundImage:homeimg forState:UIControlStateNormal];
    [home addTarget:self action:@selector(Home:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:home];
    //ストップ時リスタートのボタンを表示する
    UIImage *againimg =[UIImage imageNamed:@"リスタート.png"];
    [mouitido setBackgroundImage:againimg forState:UIControlStateNormal];
    [mouitido addTarget:self action:@selector(again:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:mouitido];
    //ストップ時再開のボタンをひょうじする
    UIImage *playimg =[UIImage imageNamed:@"再生btn.png"];
    [saikai setBackgroundImage:playimg forState:UIControlStateNormal];
    [saikai addTarget:self action:@selector(resume:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:saikai];
    
}

-(void)backHome: (UIButton *)button{
    UIViewController *view = [self.storyboard instantiateViewControllerWithIdentifier:@"Home"];
    [self presentViewController: view animated:YES completion: nil];
}

-(void)again:(UIButton*)button{
    CGRect rect= CGRectMake(self.view.frame.size.width/2 - 15,self.view.frame.size.height-100, 35,  35);
    mainBidama.frame = rect;
    [self.view addSubview:mainBidama];
    mainBidama.userInteractionEnabled = YES;
    
    
    count[0]=0;
    count[1]=0;
    count[2]=0;
    count[3]=0;
    count[4]=0;
    count[5]=0;
    count[6]=0;
    count[7]=0;
    count[8]=0;
    count[9]=0;
    
    UIImage *ballimag =[UIImage imageNamed:@"ball.png"];
    
    
    CGPoint point = ball[0].center;
    ball[0]=[[UIImageView alloc] initWithImage:ballimag];
    ball[0].center = point;
    [self.view addSubview:ball[0]];
    
    CGPoint point1 = ball[1].center;
    ball[1]=[[UIImageView alloc] initWithImage:ballimag];
    ball[1].center = point1;
    [self.view addSubview:ball[1]];
    
    CGPoint point2 = ball[2].center;
    ball[2]=[[UIImageView alloc] initWithImage:ballimag];
    ball[2].center = point2;
    [self.view addSubview:ball[2]];
    
    CGPoint point3 = ball[3].center;
    ball[3]=[[UIImageView alloc] initWithImage:ballimag];
    ball[3].center = point3;
    [self.view addSubview:ball[3]];
    
    CGPoint point4 = ball[4].center;
    ball[4]=[[UIImageView alloc] initWithImage:ballimag];
    ball[4].center = point4;
    [self.view addSubview:ball[4]];
    
    CGPoint point5 = ball[5].center;
    ball[5]=[[UIImageView alloc] initWithImage:ballimag];
    ball[5].center = point5;
    [self.view addSubview:ball[5]];
    
    CGPoint point6 = ball[6].center;
    ball[6]=[[UIImageView alloc] initWithImage:ballimag];
    ball[6].center = point6;
    [self.view addSubview:ball[6]];
    
    CGPoint point7 = ball[7].center;
    ball[7]=[[UIImageView alloc] initWithImage:ballimag];
    ball[7].center = point7;
    [self.view addSubview:ball[7]];
    
    CGPoint point8 = ball[8].center;
    ball[8]=[[UIImageView alloc] initWithImage:ballimag];
    ball[8].center = point8;
    [self.view addSubview:ball[8]];
    
    CGPoint point9 = ball[9].center;
    ball[9]=[[UIImageView alloc] initWithImage:ballimag];
    ball[9].center = point9;
    [self.view addSubview:ball[9]];
    
    Playtime = 30;
    PlayTimers = [NSTimer scheduledTimerWithTimeInterval:1
                                                  target:self
                                                selector:@selector(playtime:)
                                                userInfo:nil
                                                 repeats:YES];
    TimeLabel.text = [NSString stringWithFormat:@"%d",Playtime];
    [saikai removeFromSuperview];
    [mouitido removeFromSuperview];
    [home removeFromSuperview];
    
    
}
-(void)resume:(UIButton *)button{
    PlayTimers = [NSTimer scheduledTimerWithTimeInterval:1
                                                  target:self
                                                selector:@selector(playtime:)
                                                userInfo:nil
                                                 repeats:YES];
    mainBidama.userInteractionEnabled = YES;
    TimeLabel.text =[ NSString stringWithFormat:@"%d",Playtime ];
    
    [mouitido removeFromSuperview];
    [saikai removeFromSuperview];
    [home removeFromSuperview];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
